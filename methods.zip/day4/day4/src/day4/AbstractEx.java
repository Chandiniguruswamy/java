package day4;

public class AbstractEx {
	public static void main(String args[]) {
		Bike a=new Bike();
		a.brake();
	}

}
abstract class MotorBike {
	  abstract void brake();
	}
class Bike extends MotorBike{

	void brake() {
		System.out.println("The bike has brake");
		
	}
	
}