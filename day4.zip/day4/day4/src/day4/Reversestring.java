package day4;

public class Reversestring {
	public static void main(String args[]) {
		String str="Hello",nstr="";
		char change;
		System.out.println("Original word is: "+str);
		for(int i=0; i<str.length(); i++)
		{
			change=str.charAt(i);
			nstr=change+nstr;
		}
		System.out.println("Reversed word is: "+nstr);
	}

}
