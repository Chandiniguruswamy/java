package day4;

public class abstractclass {
	public static void main(String args[]) {
		Anim a=new Anim();
		a.eat();
		a.makeSound();
	}

}
abstract class Animal {
	  abstract void makeSound();

	  public void eat() 
	  {
		  System.out.println("Tiger eats deer");

	  }
	}
class Anim extends Animal{

	void makeSound() {
		System.out.println("Tiger makes sound");
	}
	
}
