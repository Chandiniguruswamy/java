package day7;

import java.util.Map;
import java.util.HashMap;
public class prj1 {
	
	public static void main(String args[]) {
	HashMap<String,String> color=new HashMap<>();
	color.put("color1","red");
	color.put("color","yellow");
	color.put("color3","black");
	for(Map.Entry<String,String> clr:color.entrySet())
	{
	System.out.println(clr.getKey()+" and "+clr.getValue());
	}
	}
	}

