package day7;

import java.util.HashMap;
import java.util.Map;

public class prj4 {
public static void main(String []args) {
	HashMap<String,Book> map= new HashMap<>();
	Book b1=new Book("abc",1,"1234");
	Book b2=new Book("efg",2,"1235");
	Book b3=new Book("xyz",3,"1236");
	map.put("book1",b1);
	map.put("book2",b2);
	map.put("book3",b3);
	
	for(Map.Entry<String, Book>me:map.entrySet()) {
		System.out.println(me.getKey()+" and "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().pass);
	}
}
}

class Book{
	String name,pass;
	int id;
	public Book(String name,Integer id,String pass) {
		super();
		this.name=name;
		this.id=id;
		this.pass=pass;
	}
}