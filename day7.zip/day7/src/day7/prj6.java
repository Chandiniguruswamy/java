package day7;

import java.util.HashMap;
import java.util.Map;

public class prj6 {
	public static void main(String []args) {
		HashMap<String,Teacher> map= new HashMap<>();
		Teacher t1=new Teacher("abc",2,"1");
		Teacher t2=new Teacher("efg",3,"2");
		Teacher t3=new Teacher("xyz",4,"3");
		map.put("teacher1",t1);
		map.put("teacher2",t2);
		map.put("teacher3",t3);
		
		for(Map.Entry<String, Teacher>me:map.entrySet()) {
			System.out.println(me.getKey()+" and "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().classs);
		}
	}
	}

	class Teacher{
		String name,classs;
		int id;
		public Teacher(String name,Integer id,String classs) {
			super();
			this.name=name;
			this.id=id;
			this.classs=classs;
		}
	}

