package day7;
import java.util.*;
import java.util.ArrayList;
import java.util.Set;
public class prj9 {
	
	
	public static void main(String args[])
	{
	ArrayList<String> set=new ArrayList<>();
	set.add("one");
	set.add("two");
	ListIterator i=set.listIterator();
	while(i.hasNext())
	{
	System.out.println(i.next());
	}
	while(i.hasPrevious())
	{
	System.out.println(i.previous());
	}
	}
	}

