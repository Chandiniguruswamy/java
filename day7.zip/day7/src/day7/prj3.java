package day7;
import java.util.HashMap;
import java.util.Map;
public class prj3 {
	 public static void main(String args[]) {
	HashMap<Integer,String> name=new HashMap<>();
	name.put(1,"anu");
	name.put(2,"alok");
	name.put(3,"shalu");
	for(Map.Entry<Integer,String> nm:name.entrySet())
	{
	System.out.println(nm.getKey()+" : "+nm.getValue());
	}
	}
	}



