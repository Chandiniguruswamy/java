package day7;
import java.util.ArrayList;
import java.util.Scanner;

public class prj8 {
	
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 10 number");
	ArrayList<Integer> list=new ArrayList<>();
	for(int i=0;i<10;i++)
	{
	int n=sc.nextInt();
	list.add(n);
	}
	System.out.println(list);
	ArrayList<Integer> even=new ArrayList<>();
	ArrayList<Integer> odd=new ArrayList<>();
	ArrayList<Integer> prime=new ArrayList<>();
	for(Integer s:list)
	{
	if(s%2==0)
	even.add(s);
	else
	odd.add(s);
	int a=s;
	int b=a-1;
	int count=1;
	while(b!=0)
	{
	if(a%b==0)
	count++;
	b--;
	}
	if(count==2)
	prime.add(s);
	}
	System.out.println("Even number are: "+even);
	System.out.println("Odd number are: "+odd);
	System.out.println("Prime number are: "+prime);
	}
	}

