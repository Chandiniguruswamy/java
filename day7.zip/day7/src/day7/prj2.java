package day7;
import java.util.HashMap;
import java.util.Map;

public class prj2 {

	public static void main(String args[]) {
	HashMap<String,String> subject=new HashMap<>();
	subject.put("java","88");
	subject.put("php","89");
	subject.put("android","90");
	for(Map.Entry<String,String> sub:subject.entrySet())
	{
	System.out.println(sub.getKey()+" and "+sub.getValue());
	}
	}
	}

