package day7;
import java.util.HashMap;
import java.util.Map;
public class prj7 {
	 public static void main(String args[]) {
	HashMap<String,employee1> nam=new HashMap<>();
	employee1 e1=new employee1("1","100000");
	employee1 e2=new employee1("2","126700");
	employee1 e3=new employee1("3","150000");
	nam.put("emp1",e1);
	nam.put("emp2",e2);
	nam.put("emp3",e3);
	for(Map.Entry<String,employee1> nm:nam.entrySet())
	{
	System.out.println(nm.getKey()+" : "+nm.getValue());
	}
	}
	}
	class employee1
	{
	String id,salary;
	public employee1(String id, String salary) {
	super();
	this.id = id;
	this.salary = salary;
	}
	public String toString()
	{
	return "id :+"+id+ " salary :+"+salary;
	}
	}



