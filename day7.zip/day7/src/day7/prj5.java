package day7;

import java.util.HashMap;
import java.util.Map;

public class prj5 {
	public static void main(String []args) {
		HashMap<String,Employee> map= new HashMap<>();
		Employee e1=new Employee("abc","120000",1234);
		Employee e2=new Employee("efg","130000",1235);
		Employee e3=new Employee("xyz","140000",1236);
		map.put("emp1",e1);
		map.put("emp2",e2);
		map.put("emp3",e3);
		
		for(Map.Entry<String,Employee>me:map.entrySet()) {
			System.out.println(me.getKey()+" and "+me.getValue().name+" "+me.getValue().salary+" "+me.getValue().id);
		}
	}
	}

	class Employee{
		String name,salary;
		int id;
		public Employee(String name,String salary,Integer id) {
			super();
			this.name=name;
			this.salary=salary;
			this.id=id;
		}
	}

