package day6;

public class prg1 {

}
