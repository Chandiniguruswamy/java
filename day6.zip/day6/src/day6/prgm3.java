package day6;
import java.util.ArrayList;
public class prgm3 {
	




	public static void main(String args[]) {
	ArrayList<student> list=new ArrayList<>();
	student s1=new student("chandini","464/500","454/500","322/400");
	student s2=new student("aman","100/150","434/500","343/400");
	student s3=new student("anu","800/850","434/500","233/300");
	list.add(s1);
	list.add(s2);
	list.add(s3);
	for(student s : list)
	{
	System.out.println(s.name+" "+s.mark+" "+s.mark1+" "+s.mark2);
	}
	}}
	class student{
	String name,mark,mark1,mark2;



	public student(String name,String mark,String mark1,String mark2) {
	super();
	// TODO Auto-generated constructor stub
	this.name=name;
	this.mark=mark;
	this.mark1=mark1;
	this.mark2=mark2;
	}
	}

