package day6;
import java.util.Scanner;
import java.util.ArrayList;
public class prgm2 {
	
	
	public static void main(String args[]) {
	ArrayList<Languages> list=new ArrayList<>();
	Languages l1=new Languages("java","9");
	Languages l2=new Languages("android","10");
	Languages l3=new Languages("python","8");
	list.add(l1);
	list.add(l2);
	list.add(l3);
	for(Languages x : list)
	{
	System.out.println(x.name+" "+x.mark);
	}
	}}
	class Languages{
	String name,mark;



	public Languages(String name,String mark) {
	super();
	// TODO Auto-generated constructor stub
	this.name=name;
	this.mark=mark;
	}

	}


