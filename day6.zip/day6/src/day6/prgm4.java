package day6;
import java.util.ArrayList;

public class prgm4 {
	
	public static void main(String args[])
	{
	ArrayList<book> list=new ArrayList<>();
	book l1=new book("java","1","1000","james gosling");
	book l2=new book("android","2","2000","Andy Rubin");

	list.add(l1);
	list.add(l2);

	for(book x : list)
	{
	System.out.println(x.bookname+" "+x.id+" "+x.price+" "+x.authorname);
	}
	}}
	class book{
	String bookname,id,price,authorname;



	public book(String bookname,String id,String price,String authorname) {
	super();
	
	this.bookname=bookname;
	this.id=id;
	this.price=price;
	this.authorname=authorname;
	}
	}

