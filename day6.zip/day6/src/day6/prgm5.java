package day6;

import java.util.ArrayList;
import java.util.List;

public class prgm5 {
public static void main(String [] args) {
	List<Integer> list= new ArrayList<Integer>();
	list.add(10);
	list.add(20);
	list.add(30);
	list.add(40);
	System.out.println("list"+list);
	//get
	int element=list.get(3);
	System.out.println("element at index 3 is:"+element);
	//clear()
	list.clear();
	System.out.println("list after clear method"+list);
	//isEmpty()
	list.isEmpty();
	if(list.isEmpty()==true){
		System.out.println("list is empty");
	}
	else {
		System.out.println("list is not empty");
	}
	List<Integer> list1= new ArrayList<Integer>();
	list1.add(1);
	list1.add(2);
	list1.add(3);
	System.out.println("list1:"+list1);
	List<Integer> list2= new ArrayList<Integer>();
	list2.add(4);
	list2.add(5);
	list2.add(6);
	System.out.println("list2"+list2);
	//addAll()
	list1.addAll(list2);
	System.out.println("printing all elements from both lists"+list1);
	//remove()
	list1.remove(3);
	System.out.println("list after an element is removed:"+list1);
	//removeAll()
	list1.removeAll(list2);
	System.out.println("list:"+list1);
	
}
}
