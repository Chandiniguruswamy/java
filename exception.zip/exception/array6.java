package exception;

import java.util.Scanner;

public class array6 {
	
	    public static void main(String aa[]) 
	    {
	        int flag=0;
	        int sum=0;
	        Scanner s=new Scanner(System.in);
	        System.out.println("Enter size of array");
	        int size=s.nextInt();

	    int numbers[]= new int[size];
	    System.out.println("Enter the elements of array : ");
	    for(int i=0;i<size;i++)
	    {
	    numbers[i]=s.nextInt();
	    if(numbers[i]%2==0)
	    {
	    flag++;    
	    }
	    }       
	 
	    if(flag==size)
	    System.out.println("all elements are even");
	    else
	        System.out.println("all elements are not even");
	    }
	
}
