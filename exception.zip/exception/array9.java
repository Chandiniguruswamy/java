package exception;

public class array9 {
	public static void main(String[] args) {
		char array[]= {'a','b','i','x','u'};
		
		int count=0;
		int length=array.length;
		for(int i=0;i<length;i++) {
			if(array[i]=='a'||array[i]=='e'||array[i]=='i'||array[i]=='o'||array[i]=='u')
			{
		      count++;
			}
		}
		System.out.println("the number of vowels in array are:"+count);
		
	}
}
