package exception;

public class array8 {
public static void main(String[] args) {
	char array[]= {'a','b','i','x','u'};
	
	int length=array.length;
	for(int i=0;i<length;i++) {
		if(array[i]=='a'||array[i]=='e'||array[i]=='i'||array[i]=='o'||array[i]=='u')
		{
			System.out.println("vowels in array is:"+array[i]);
		}
	}
	
}
}
