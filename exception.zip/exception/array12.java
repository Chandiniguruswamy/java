package exception;

import java.util.Scanner;

public class array12 {
 public static void main(String[] args) {
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter array size");
	 int size=sc.nextInt();
	 System.out.println("enter number to check duplicacy");
	 int n=sc.nextInt();
	 System.out.println("enter array elements");
	 int[] arr=new int[size];
	 int dupe=-1;
	 for(int i=0;i<size;i++) {
		 arr[i]=sc.nextInt();
		 if(arr[i]==n) {
			 dupe++;
		 }
	 }
	 System.out.println("the number of duplicacy of "+n+" is"+dupe);
 }
}
