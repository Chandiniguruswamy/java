package exception;

public class array4 {
	 public static void main(String aa[])
	    {
	    char vowels[]= {'a','e','i','o','u'};

	    for(int i=0;i<vowels.length;i++)
	    {
	        System.out.println(vowels[i]);
	    }

	    }
}
