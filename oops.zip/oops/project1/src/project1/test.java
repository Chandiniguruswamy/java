package project1;

public class test {
	public static void main(String a[])
	{
		String name="chandni";
		String learning="java";
		int age=22;
		System.out.println("My Details");
		System.out.println("My name is :"+name);
		System.out.println("I am learning :"+learning);
		System.out.println("My age is :"+age);
		
	}
	

}
