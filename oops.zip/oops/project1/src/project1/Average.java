package project1;

public class Average {
	public static void main(String args[])
	{
		int a=10,b=15,c=20,d=25,e=30,sum;
		sum=(a+b+c+d+e)/5;
		System.out.println("The average of 5 number is:"+sum);
		
	}

}
