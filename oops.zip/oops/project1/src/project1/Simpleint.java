package project1;

public class Simpleint {
	public static void main(String args[])
	{
		float p,r,t,si;
		p=10000;
		r=12;
		t=3;
		si=(p*r*t)/100;
		System.out.println("simple interest is:"+si);
	}

}