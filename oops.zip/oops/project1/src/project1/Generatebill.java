package project1;

import java.util.Scanner;

public class Generatebill {
	public static void main(String args[]) {
		int units=160;
		if(units<=50)
		{
			System.out.println("Free");
			
		}
		else if(units>50 && units<=100)
		{
			units=(units-50)*6;
			System.out.println(units);
		}
		else if(units>100 && units<=150)
		{
			units=(units-100)*8+(50*6);
			System.out.println(units);
		}
		else{
			units=(units-150)*9+(50*6)+(50*8);
			System.out.println(units);
		}
	}
}