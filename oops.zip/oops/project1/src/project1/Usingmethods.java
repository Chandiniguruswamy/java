package project1;

import java.util.Scanner;

public class Usingmethods 
{
	public static void main(String args[]) 
	{
		Usingmethods fact=new Usingmethods();
		fact.method1(5);
		fact.method2(34,5,665,76);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius of circle");
		double num1=sc.nextDouble();
		fact.method3(num1);

	}
	void method1(int number)
	{
		int a=1;
		for(int i=1; i<=number; i++)
		{
			a=a*i;
		}
		System.out.println("Factorial of "+number+" is :"+a);
	}
	void method2(float a,float b, float c,float d)
	{
		float sum=a+b+c+d;
		System.out.println("The sum of numbers is:"+sum);
	}
	void method3(double num1)
	{
		double area=3.14*num1*num1;
		System.out.println("the area of circle is :"+area);
	}

}

