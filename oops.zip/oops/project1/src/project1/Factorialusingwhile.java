package project1;

public class Factorialusingwhile {
	public static void main(String args[]) {
		int fact=1;
		int i=1;
		int num=4;
		do {
			fact=fact*i;
			i++;
		}while(i<=num);
		System.out.println("Factorial of number is"+fact);
	}

}
