package project1;

public class Constructor {
	public static void main (String args[]){
		Car a=new Car("Ferrari","10");
		a.carDetails();
	}

}
class Car{
	String brand,price;
	
	Car(String br,String pr)
	{
		brand=br;
		price=pr;
	}
	void carDetails()
	{
		System.out.println("Car brand is: "+brand+"\ncar price is: "+price+" Crore.Rs");
	}
}