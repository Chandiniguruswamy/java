package project1;

public class Methodex {
	String name,rollno;

	void setName(String name)
	{
	    this.name=name;
	}
	 
	void setRollno(String rollno)
	{
	    this.rollno=rollno;    
	}
	 
	String getName()
	{
	    return name;
	}
	 
	String getRollno()
	{
	    return rollno;
	}
	 
	

	public static void main (String args[]){
			 Methodex t1=new Methodex();
	          t1.setName("chandni");
	          t1.setRollno("12");

	          System.out.print("Name:"+t1.getName()+"\nAge:"+t1.getRollno());

}
}