package project1;

public class Checkgrade {
	public static void main(String args[]) {
		int marks=90;
		if(marks>=90)
		{
			System.out.println("Student grade is A");
		}
		else if(marks>=70 && marks<90)
		{
			System.out.println("Student grade is B");
		}
		else if(marks>60 && marks<70)
		{
			System.out.println("Student grade is pass");
		}
		else if(marks<60)
		{
			System.out.println("Student is fail");
		}
	}

}
