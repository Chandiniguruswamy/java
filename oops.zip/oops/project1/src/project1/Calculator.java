package project1;

import java.util.Scanner;

public class Calculator {
	public static void main(String args[]) {
		char operator;
		String choice;
		do {
		int num1,num2,result;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number");
		num1=sc.nextInt();
		System.out.println("Enter the second number");
		num2=sc.nextInt();
		System.out.println("Select your operation:");
		System.out.println("1.Enter + for Addition:");
		System.out.println("2.Enter - for Substraction:");
		System.out.println("3.Enter * for Multiplication:");
		System.out.println("4.Enter / for Division:");
		operator=sc.next().charAt(0);
		switch(operator) {
		case '+':
			result=num1+num2;
			System.out.println("Addition of two number is :"+result);
			break;
		case '-':
			result=num1-num2;
			System.out.println("substraction of two number is :"+result);
			break;
		case '*':
			result=num1*num2;
			System.out.println("Multiplication of two number is :"+result);
			break;
		case '/':
			result=num1/num2;
			System.out.println("Division of two number is :"+result);
			break;
		
		default:
			System.out.println("Invalid operator");
			break;
		}
		System.out.print("Do you want to continue?(yes/no)");
        choice=sc.next();
		}while(choice.equals("YES")|| choice.equals("yes"));
        System.out.print("Thankyou!!!");
	}

}
