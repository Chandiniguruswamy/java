package project1;

public class Areaofcircle {
	public static void main(String args[])
	{
		int radius;
		double pi=3.14,area;
		radius=5;
		area=pi*radius*radius;
		System.out.println("Area of circle is:"+area);
	}

}
