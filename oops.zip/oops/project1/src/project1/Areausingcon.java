package project1;

public class Areausingcon {
	public static void main (String args[]){
		Area circle=new Area(3.14,3);
		Areas rectangle=new Areas(5,5);
		
	}

}
class Area{
	double pi,radius;
	
	Area(double p,double rad)
	{
		double sum;
		pi=p;
		radius=rad;
		sum=pi*rad;
		System.out.println("Area of circle is :"+sum);
	}
	
}

class Areas{
	double length,height;
	
	Areas(double len,double hei)
	{
		double sum;
		length=len;
		height=hei;
		sum=length*hei;
		System.out.println("Area of circle is :"+sum);
	}
	
}
