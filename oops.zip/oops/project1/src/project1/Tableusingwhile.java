package project1;

public class Tableusingwhile {
	public static void main(String args[]) {
		int num=5,i=1;
		do {
			System.out.println("5*"+i+"="+num*i);
			i++;
		}while(i<=10);
	}

}
