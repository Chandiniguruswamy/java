package project1;
import java.util.Scanner;
public class Greatestog3num {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number");
		int a=sc.nextInt();
		System.out.println("Enter the second number");
		int b=sc.nextInt();
		System.out.println("Enter the third number");
		int c=sc.nextInt();
		int largest;
		
		if(a>b && a>c)
		{
			System.out.println("The greatest number is:"+a);
		}
		if(b>a && b>c)
		{
			System.out.println("The greatest number is:"+b);
		}
		if(c>b && c>a)
		{
			System.out.println("The greatest number is:"+c);
		}
	}
	

}
